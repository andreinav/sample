
//CREATE FUNCTIONS
//Focus on field
//Use: when loading the page, it makes it focus on the first name field
document.getElementById("fname").focus()

//Function hint
//use: removes pre-defined text from field box when click-on
function hint(obj, message) {
     var defaultText = message
     var txtElem = document.getElementById(obj);
     txtElem.value = defaultText;
     txtElem.style.color = "#A8A8A8";
     txtElem.style.fontStyle = "italic";
     txtElem.onfocus = function() {

      //if there is a text filled in the field, keep ot
      if (this.value === defaultText) {
        this.value = "";
        this.style.color = "#000";
    	this.style.fontStyle = "normal";
      }
     }
     //on blur: if the filed is empty, return message
     txtElem.onblur = function() {
      if (this.value === "") {
        this.value = defaultText;
        this.style.color = "#A8A8A8";
    	this.style.fontStyle = "italic";
  }
 }
}

//Wrapper function that triggers hint for all relevant IDs
//use: runs hint function for all relevant IDs
function hint_all () {
  hint("fname", "Enter your first name");
  hint("lname", "Enter your last name");
  hint("email", "Enter your email");
  hint("tele", "Enter your telephone");
  hint("hanumber", "Enter your Health Number");
}


//function tooltip help item
  function switchToolTip() {

  document.getElementById('qmark').onmouseover = function() {
  var toolTip = document.getElementById('ttip');
  toolTip.style.display='block';

  }

  document.getElementById('qmark').onmouseout = function() {
  var toolTip = document.getElementById('ttip');
  toolTip.style.display='none';
  }
}



//Validate function
function formValidation() {
// Make quick references to  fields.
var firstname = document.getElementById('fname');
var lastname = document.getElementById('lname');
var title = document.getElementById('title');
var number = document.getElementById('hanumber');
var telephone = document.getElementById('tele');
var email = document.getElementById('email');

// To check empty form fields.
if (firstname.value.length == "" ||
    lastname.value.length == "" ||
    number.value.length == "" ||
    telephone.value.length == "" ||
    email.value.length == "" )

    {
    document.getElementById('head').innerText = "* All fields are mandatory *"; // This segment displays the validation rule for all fields
    return false;
    }

// Check each input in the order that it appears in the form.
if (inputAlphabetname(firstname, "* For your name please use alphabets only *")) {
if (inputAlphabetlast(lastname, "* For your last name please use alphabets only *")) {
if (trueSelection(title, "* Please Choose any one option")) {
if (textNumeric(hanumber, 6, 6)) {
if (emailValidation (email, "* Please enter email address *")) {
if (textNumeric(telephone, 11, 11)) {
}
}
}
}
}
}
}

///////////////////////////
//FUNCTIONS GENERIC
///////////////////////////



///////////////////////////
// Function that checks whether input text is an alphabetic character or not.
function inputAlphabetname(inputtext, alertMsg) {
var alphaExp = /^[a-zA-Z]+$/;
  if (inputtext.value.match(alphaExp)) {
  return true;
  } else {
  document.getElementById('p1').innerText = alertMsg;
  //alert(alertMsg);
  inputtext.focus();
  return false;
}
}

///////////////////////////
// Function that checks whether input text is an alphabetic character or not.
function inputAlphabetlast(inputtext, alertMsg) {
var alphaExp = /^[a-zA-Z_-]+$/;
  if (inputtext.value.match(alphaExp)) {
  return true;
  } else {
  document.getElementById('p2').innerText = alertMsg;
  //alert(alertMsg);
  inputtext.focus();
  return false;
}
}

///////////////////////////
// Function that checks whether a option is selected from the selector and if it's not it displays an alert message.
function trueSelection(inputtext, alertMsg) {
  if (inputtext.value == "Please Choose") {
  document.getElementById('p3').innerText = alertMsg;
  inputtext.focus();
  return false;
  } else {
  return true;
}
}


///////////////////////////
// Function that checks whether input text is numeric or not.
function textNumeric(inputtext, mix, max) {
  var numericExpression = /^ZHA([0-9]{6,6})/;
    if (inputtext.value.match(numericExpression)) {
    return true;
  } else {
    document.getElementById('p4').innerText = "*Please enter only numeric values without spaces";
    inputtext.focus();
    return false;
  }

  var uInput = inputtext.value;
    if (uInput.length >= min && uInput.length <= max) {
    return true;
  } else {
    document.getElementById('p4').innerText = "* Please enter the last 6 digits of your ZHA Health number";
    return false;
}
} //end of function

/////////////////////////
//Function that checks whether an user entered valid email address or not and displays alert message on wrong email address format.
function emailValidation(inputtext, alertMsg) {
  var emailExp = /^[w-.+]+@[a-zA-Z0-9.-]+.[a-zA-z0-9]{2,4}$/;
    if (inputtext.value.match(emailExp)) {
    return true;
  } else {
    document.getElementById('p5').innerText = alertMsg;
    inputtext.focus();
  return false;
}
}//end of function

//Function: text numeric for telephone
function textNumeric(inputtext, mix, max) {
  var numericExpression = /^([0-9]{11,11})/;
    if (inputtext.value.match(numericExpression)) {
    return true;
  } else {
    document.getElementById('p6').innerText = "Please enter only numeric values without spaces";
    inputtext.focus();
    return true;
}
} //end of function


//LOAD FUNCTIONS
//window.onload=formValidation();
window.onload=hint_all();
window.onload=switchToolTip();
