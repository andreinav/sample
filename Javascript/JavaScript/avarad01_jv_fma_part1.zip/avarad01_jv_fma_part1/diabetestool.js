
//create variable radios with the radio button values
var radios = document.getElementsByTagName("input")
var risk1, risk2


function calculateTotal() {
  var objectArray = [];	// initialize empty array
  var total = 0;
  for (i = 0; i < radios.length; i++) {
    if (radios[i].type == 'radio' && radios[i].checked) {

      //save the values and names of the radio buttons into an array of objects
    	objectArray.push({
    		value: Number(radios[i].value),
    		name: radios[i].name
    	});
    	total += Number(radios[i].value);
    }
  }
  //sorting the array ascending
  objectArray.sort(function(a, b){return a.value - b.value});

  // getting the name property of the last two values of the array that are the highest in value
  risk1 = objectArray[objectArray.length - 1].name;
  risk2 = objectArray[objectArray.length - 2].name;
  return total;
}


//Display message Function
function displaymessage () {

  //create empty variable
  var message = 0

  //run function calculate total and store in score var
  score = calculateTotal()


  //Depending on your score, you get a message in the bottom of the form
  var messagebase = "Your results show that you currently have a low risk of developing diabetes."
  var str = "ZHA Health Authority";
  var result = str.link("http://zha.org.zd");
  var link = str.link ("http://diabetestool.html");

 if (score < 15) {
  message = "Your results show that you currently have a low risk of developing diabetes"
} else if (score > 25) {
  message = "Your results show that you currently have a high risk of developing diabetes. Your main risk are " + risk1 + " and " + risk2 + "We advise that you contact the Health Authoirity to discuss your risk factors as soon as you can. Please fill in our form (" + link +  ") and a member of the Health Authority Diabetes Team will be in contact with you"
} else {
  message = "Your results show that you currently have a medium risk of developing diabetes. For more information on your risk factors, and what do to do about them, please visit our diabetes advice website at " + result
}

  //push result to element display message on HTML that comes up once you hit calculate
  document.getElementById('displaymessage').innerHTML = message;

}

document.getElementById('assessment').addEventListener("submit", function(event) {
    event.preventDefault();
    displaymessage();
});
