

//Jquery validation form function

$(document).ready(function () {

    $('#form').validate({ // initialize the plugin

//rules of the game
        rules: {
            firstname: {
                required: true,
                minlength:2,
                lettersonly: true
            },
            lastname: {
                required: true,
                minlength: 2,
                letterswithbasicpunc: true,
            },
            title: {
                required: true,
            },
            HealthAuthorityNumber: {
                required: true,
                pattern: "^ZHA([0-9]{6,6})"
            },
            email: {
                required: true,
                email: true,
            },
            tele: {
                required: false,
                minlength: 11,
                phonesUK: true,
            }
        }, //close rules

//mesages
        messages: {
          firstname: {
            required: "Please specify your name",
          },
          lastname: {
            required: "Please specify your last name",
          },
          HealthAuthorityNumber: {
            required: "Your HA Number starts with ZHA followed by 6 digits",
          },
          email: {
            required: "Your email address must be in the format of name@domain.com",
          }

        } //close message

    }); //close validate

}) //close function


//notes used:
//https://www.w3schools.com/
//https://stackoverflow.com/questions/tagged/jquery-form-validator
//https://jqueryvalidation.org/validate/
//https://moodle.bbk.ac.uk/mod/folder/view.php?id=396414
//https://regexr.com/
