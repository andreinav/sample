

//create ask person to plug-in 6 numbers to create customerNumber array

//create empty variable to store inputs
var customerNumber = [];

//create customer number by asking the user to log in 6 Numbers
//note: if they log in a string, the program will collapse

for (i = 0; i < 6; i++) {
  customerNumber.push (parseInt(prompt('Enter number ' + (i+1))));
}

//define global variable with winning numbers of lottery
var winningNumbers = [12,17,24,37,38,43];

//function: get the customer number
function getCustomerNumber() {
  return (customerNumber);
}

//function: get the winning number
function getWinningNumbers() {
  return (winningNumbers);
}


//function: check that the customer numbers is in the winning numbers array
//input = custNum: temporary customernumber variable
//input = winNum: temporary winningnumbers variable
//output = count: number of matches

function checkNumbers (custNum,winNum) {

  //variable that acts like a "counter"
  var count = 0;

  //loop for customernumber
  for (var i = 0; i < custNum.length; ++i) {
    var cn = custNum[i];

    //loop for winning number
    for (var j = 0; j < winNum.length; ++j) {
      if (cn == winNum[j])
      count++;
    }
  }
return (count);

}

//function: display result
//output = count: number of matches
function displayResult (){
  count = checkNumbers(getCustomerNumber(), getWinningNumbers());

//create generic message to be displayed. Variable message
var message =
"This Week's Winning Numbers are: " + winningNumbers +
"\n" + "The Customer Number is " + customerNumber +
"\n" + "Numbers matched"


//design message based on output of function
alert (message + "\n" + count)

}


//start the ball rolling
function init (){
displayResult();
}


window.onload = init;
