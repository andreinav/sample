//Task 5. Functions
//author: Andreina Varady
//date: June,1,2018


//create global variables
var customerNumber = 13;
var winningNumbers = [12,17,24,37,38,43];



//Get the customer number
function getCustomerNumber() {
   var CustomerNumber = 13;
   return(CustomerNumber);
	 //alert (CustomerNumber)
}

//Get the winning number
function getWinningNumbers() {
   var winningNumbers = [12,17,24,37,38,43];
   return (winningNumbers);
}

//Check that the customer number is in the winning array
function checkNumbers (x,y) {
		match = y.includes(customerNumber);
		return (match);
	}



//Display message function
function displayResult (){
   match = checkNumbers(getCustomerNumber(), getWinningNumbers());

	 //create message
	 var message = "This Week's Winning Numbers are: " + winningNumbers + "\n" + "The Customer Number is " + customerNumber;

	 //design message based on output of function
	 if (match == true) {
		alert (message + "\n" + "We have a match and a winner!");

	  } else {
		alert (message + "\n" + "Sorry,you are not a winner this week!");
	  }
   }


//Start the ball rolling
	function init (){
   displayResult();
}

window.onload = init;
