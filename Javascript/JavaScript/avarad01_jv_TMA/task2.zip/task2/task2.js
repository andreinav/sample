//Task 2. Variables and Arrays
//author: Andreina Varady
//date: June,1,2018

//define variable customer number
var customerNumber = 12;

//define variable winning number
var winningNumber = [12, 17, 24, 37, 38, 43];

//create alert box with content of variables:
//customerNumber and winningNumber
alert ("This Week's Winning Numbers are " + winningNumber + "\n" + "The Customer's Number is " + customerNumber);
