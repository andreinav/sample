//Task 1. Creating and Linking to a JavaScript File
//author: Andreina Varady
//date: June,1,2018

alert("hello professor!");
